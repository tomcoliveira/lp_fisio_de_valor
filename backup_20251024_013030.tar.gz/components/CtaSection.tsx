import React, { useEffect } from 'react';

const CtaSection: React.FC = () => {
  useEffect(() => {
    // Carrega o script do widget Hotmart
    const script = document.createElement('script');
    script.src = 'https://static.hotmart.com/checkout/widget.min.js';
    script.async = true;
    document.head.appendChild(script);

    // Carrega o CSS do Hotmart
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = 'https://static.hotmart.com/css/hotmart-fb.min.css';
    document.head.appendChild(link);

    return () => {
      // Cleanup ao desmontar
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
      if (link.parentNode) {
        link.parentNode.removeChild(link);
      }
    };
  }, []);

  return (
    <section id="cta" className="py-24 md:py-32 px-4 bg-teal-50">
      <div className="container mx-auto max-w-4xl text-center">
        <h2 className="font-display text-4xl md:text-6xl font-bold text-gray-900">
          SEJA O FISIO DE VALOR.
        </h2>
        <p className="text-lg text-gray-700 mt-4 max-w-2xl mx-auto">
          A mentoria que vai transformar seu trabalho em reconhecimento, previsibilidade e renda real.
        </p>

        <div className="mt-12 flex justify-center">
          <a 
            onClick={(e) => {
              e.preventDefault();
              return false;
            }}
            href="https://pay.hotmart.com/Q95596464W?checkoutMode=2" 
            className="hotmart-fb hotmart__button-checkout inline-block transform hover:scale-105 transition-all"
          >
            <img 
              src="https://static.hotmart.com/img/btn-buy-green.png" 
              alt="Comprar agora"
              className="h-auto w-auto max-w-full"
            />
          </a>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;